import cv2
import os

# Define gesture categories
gestures = ["thumbs_up", "thumbs_down", "peace", "fist"]
for gesture in gestures:
    os.makedirs(f"dataset/{gesture}", exist_ok=True)

cap = cv2.VideoCapture(0)
current_gesture = gestures[0]
count = 0

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)  # Flip for better user experience

    # Convert to grayscale & apply threshold for segmentation
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 70, 255, cv2.THRESH_BINARY)

    # Show the processed frame
    cv2.putText(frame, f"Gesture: {current_gesture}", (10, 40), 
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.imshow("Hand Gesture Capture", frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('s'):  # Press 's' to save image
        filename = f"dataset/{current_gesture}/{count}.jpg"
        cv2.imwrite(filename, thresh)
        count += 1
        print(f"Saved {filename}")

    elif key == ord('n'):  # Press 'n' to switch gesture
        current_gesture = gestures[(gestures.index(current_gesture) + 1) % len(gestures)]
        count = 0
    
    elif key == ord('q'):  # Press 'q' to quit
        break

cap.release()
cv2.destroyAllWindows()
