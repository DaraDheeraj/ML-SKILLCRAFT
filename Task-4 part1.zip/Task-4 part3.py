import cv2
import numpy as np
from tensorflow.keras.models import load_model

model = load_model("gesture_model.h5")

labels = ["thumbs_up", "thumbs_down", "peace", "fist"]

cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)

    # Convert frame to grayscale and apply threshold
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 70, 255, cv2.THRESH_BINARY)

    # Resize and preprocess for prediction
    hand_crop = cv2.resize(thresh, (64, 64))
    hand_crop = np.expand_dims(hand_crop, axis=[0, -1]) / 255.0

    # Predict gesture
    prediction = model.predict(hand_crop)
    gesture = labels[np.argmax(prediction)]

    cv2.putText(frame, f"Gesture: {gesture}", (10, 40), 
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.imshow("Real-time Gesture Recognition", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
